import React, { useState, useEffect } from 'react';
import { formatLocalDate, getVehicleExpiryStatus } from '../../utils/dateUtils';


import { useNavigate } from 'react-router-dom';
import { Users, Users2, Truck, Activity, AlertTriangle } from 'lucide-react';

import { useVehicles } from '../../hooks/useVehicles';
import { getDashboardStats } from '../../api/adminApi';
import { useAuth } from '../../hooks/useAuth';
import CustomerDashboard from './CustomerDashboard';

const StatCard = ({ label, value, color, icon: Icon, onClick }) => (
  <div
    onClick={onClick}
    className="flex-1 min-w-[140px] md:min-w-[160px] p-3 md:p-4 bg-white rounded-[12px] md:rounded-[16px] border border-slate-100 shadow-[0_4px_12px_rgba(0,0,0,0.04)] cursor-pointer transition-all duration-200"
    style={{
      borderTop: `4px solid ${color}`,
      display: 'flex',
      alignItems: 'center',
      gap: '12px',
    }}
    onMouseEnter={e => {
      e.currentTarget.style.transform = 'translateY(-2px)';
      e.currentTarget.style.boxShadow = `0 12px 24px ${color}15`;
      e.currentTarget.style.borderColor = `${color}30`;
      e.currentTarget.style.borderTopColor = color;
    }}
    onMouseLeave={e => {
      e.currentTarget.style.transform = 'none';
      e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.04)';
      e.currentTarget.style.borderColor = '#F1F5F9';
      e.currentTarget.style.borderTopColor = '#2E4867';
    }}
  >
    <div className="w-[32px] h-[32px] md:w-[40px] md:h-[40px] rounded-[10px] md:rounded-[12px] shrink-0 flex items-center justify-center" style={{
      background: `${color}10`,
    }}>
      <Icon className="w-[16px] md:w-[20px] h-[16px] md:h-[20px]" color={color} />
    </div>
    <div>
      <div className="text-[18px] md:text-[24px] font-[800] text-gray-900 leading-none">
        {value}
      </div>
      <div className="text-[11px] md:text-[13px] text-gray-500 font-[600] mt-[2px]">
        {label}
      </div>
    </div>
  </div>
);

const LicenseCard = ({ title, total, used, available, color, labelUsed = 'Used', labelAvailable = 'Available' }) => (
  <div 
    className="flex-1 min-w-[140px] md:max-w-[220px] p-3 md:p-4 bg-white rounded-[12px] md:rounded-[16px] border border-slate-100 shadow-[0_4px_12px_rgba(0,0,0,0.04)] transition-all duration-200 flex flex-col items-center justify-center"
    style={{
      borderTop: `4px solid ${color}`,
    }}
    onMouseEnter={e => {
      e.currentTarget.style.transform = 'translateY(-2px)';
      e.currentTarget.style.boxShadow = `0 12px 24px ${color}15`;
      e.currentTarget.style.borderColor = `${color}30`;
      e.currentTarget.style.borderTopColor = color;
    }}
    onMouseLeave={e => {
      e.currentTarget.style.transform = 'none';
      e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.04)';
      e.currentTarget.style.borderColor = '#F1F5F9';
      e.currentTarget.style.borderTopColor = '#2E4867';
    }}
  >
    <div className="text-[12px] md:text-[14px] text-gray-900 font-[700]">{title}</div>
    <div className="text-[24px] md:text-[32px] font-[800] leading-none mt-[6px] mb-[10px] md:mb-[12px]" style={{ color: color }}>{total}</div>
    <div className="flex w-full justify-around border-t border-slate-100 pt-[8px] md:pt-[12px]">
      <div className="flex flex-col items-center">
        <span className="text-[9px] md:text-[11px] text-gray-500 font-[600]">{labelUsed}</span>
        <span className="text-[13px] md:text-[15px] font-[700]" style={{ color: color }}>{used}</span>
      </div>
      <div className="w-[1px] bg-slate-50"></div>
      <div className="flex flex-col items-center">
        <span className="text-[9px] md:text-[11px] text-gray-500 font-[600]">{labelAvailable}</span>
        <span className="text-[13px] md:text-[15px] font-[700]" style={{ color: color }}>{available}</span>
      </div>
    </div>
  </div>
);



const DashboardPage = ({ setAppVehicles }) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { vehicles, groups, loading, error } = useVehicles();
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [quota, setQuota] = useState(null);
  const [apiStats, setApiStats] = useState(null);
  const isDealer = user?.role === 'dealer';

  // Customer role gets the map-based fleet dashboard
  if (user?.role === 'customer') {
    return <CustomerDashboard setAppVehicles={setAppVehicles} />;
  }

  useEffect(() => {
    if (vehicles && setAppVehicles) setAppVehicles(vehicles);
  }, [vehicles, setAppVehicles]);

  useEffect(() => {
    getDashboardStats()
      .then(res => {
        if (res.success) setApiStats(res.data);
      })
      .catch(err => console.error("Failed to fetch dashboard stats", err));
  }, [vehicles]);

  useEffect(() => {
    if (isDealer) {
      import('../../api/adminApi').then(api => {
        api.getDeviceQuota().then(res => {
          if (res.success) setQuota(res.data);
        }).catch(err => console.error("Failed to fetch quota", err));
      });
    }
  }, [isDealer]);

  const onlineCount = vehicles.filter(v => v.is_online).length;

  const totalUsers = apiStats?.users ?? '-';
  const totalGroups = groups.length || '-';
  const totalVehicles = apiStats?.total_vehicles ?? vehicles.length;

  const getTierStats = (type) => {
    if (isDealer && quota) {
      return {
        total: quota.limits?.[type] || 0,
        used: quota.used?.[type] || 0,
        available: quota.available?.[type] || 0,
        labelUsed: 'Used',
        labelAvailable: 'Available'
      };
    } else {
      // Superadmin or fallback
      const typePrefixes = { 'Starter': 'ST', 'Basic': 'BC', 'Advanced': 'AD', 'Premium': 'EN' };
      const prefix = typePrefixes[type];

      let typeVehicles = vehicles.filter(v => {
        if (v.metadata?.licenceType === type) return true;
        if (v.licenceId && v.licenceId.startsWith(prefix)) return true;
        return false;
      });

      const online = typeVehicles.filter(v => v.is_online).length;
      return {
        total: typeVehicles.length,
        used: online,
        available: typeVehicles.length - online,
        labelUsed: 'Online',
        labelAvailable: 'Offline'
      };
    }
  };

  const starterStats = getTierStats('Starter');
  const basicStats = getTierStats('Basic');
  const advancedStats = getTierStats('Advanced');
  const premiumStats = getTierStats('Premium');

  // Compute expiring licenses within 30 days
  const thirtyDaysFromNow = new Date();
  thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);

  const expiringVehicles = vehicles.filter(v => {
    if (!v.licence_expire_date) return false;
    const expireDate = new Date(v.licence_expire_date);
    return expireDate <= thirtyDaysFromNow;
  }).sort((a, b) => new Date(a.licence_expire_date) - new Date(b.licence_expire_date));

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 56px)', background: 'linear-gradient(to bottom, #f0f9ff 0%, #f0f9ff 30%, #f0f9ff 30%, #f0f9ff 100%)', overflowY: 'auto' }}>

      {/* KPI Cards Row (Moved Basic Card Here) */}
      <div className="p-4 md:p-6 flex flex-wrap items-stretch shrink-0 gap-3 md:gap-5">
        <StatCard label="Users" value={totalUsers} color="#7C3AED" icon={Users} onClick={() => navigate('/admin/users')} />
        <StatCard label="Groups" value={totalGroups} color="#3B82F6" icon={Users2} onClick={() => navigate('/admin/groups')} />
        <StatCard label="Vehicles" value={totalVehicles} color="#EC4899" icon={Truck} onClick={() => navigate('/admin/vehicles')} />

        <LicenseCard
          title="Starter"
          total={starterStats.total}
          used={starterStats.used}
          available={starterStats.available}
          labelUsed={starterStats.labelUsed}
          labelAvailable={starterStats.labelAvailable}
          color="#10B981"
        />
        <LicenseCard
          title="Basic"
          total={basicStats.total}
          used={basicStats.used}
          available={basicStats.available}
          labelUsed={basicStats.labelUsed}
          labelAvailable={basicStats.labelAvailable}
          color="#3B82F6"
        />
        <LicenseCard
          title="Advanced"
          total={advancedStats.total}
          used={advancedStats.used}
          available={advancedStats.available}
          labelUsed={advancedStats.labelUsed}
          labelAvailable={advancedStats.labelAvailable}
          color="#F59E0B"
        />
        <LicenseCard
          title="Premium"
          total={premiumStats.total}
          used={premiumStats.used}
          available={premiumStats.available}
          labelUsed={premiumStats.labelUsed}
          labelAvailable={premiumStats.labelAvailable}
          color="#8B5CF6"
        />
      </div>

      {/* Main Layout: Expiring Licenses */}
      <div style={{ display: 'flex', padding: '0 24px 24px 24px', minHeight: '500px', flexShrink: 0 }}>
        <div style={{
          flex: 1,
          background: '#FFFFFF',
          borderRadius: '16px',
          border: '1px solid #E2E8F0',
          boxShadow: '0 4px 6px rgba(0,0,0,0.02)',
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden'
        }}>
          <div style={{ padding: '20px', borderBottom: '1px solid #F1F5F9', background: '#FAFAF9' }}>
            <h3 style={{ fontSize: '18px', fontWeight: 700, color: '#111827', display: 'flex', alignItems: 'center', gap: '8px', margin: 0 }}>
              <AlertTriangle size={20} color="#F59E0B" />
              Expiring Vehicle Licenses
            </h3>
            <p style={{ fontSize: '13px', color: '#6B7280', marginTop: '4px', margin: 0 }}>Vehicles requiring license renewal</p>
          </div>

          <div style={{ flex: 1, overflowY: 'auto', padding: '0' }}>
            {expiringVehicles.length > 0 ? (
              <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                <thead style={{ position: 'sticky', top: 0, background: '#FFFFFF', zIndex: 1 }}>
                  <tr style={{ borderBottom: '2px solid #F1F5F9' }}>
                    <th style={{ padding: '16px 20px', fontSize: '13px', color: '#6B7280', fontWeight: 600 }}>Vehicle Name</th>
                    <th style={{ padding: '16px 20px', fontSize: '13px', color: '#6B7280', fontWeight: 600 }}>Registration No</th>
                    <th style={{ padding: '16px 20px', fontSize: '13px', color: '#6B7280', fontWeight: 600 }}>Expiry Date</th>
                    <th style={{ padding: '16px 20px', fontSize: '13px', color: '#6B7280', fontWeight: 600 }}>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {expiringVehicles.map(v => {
                    const status = getVehicleExpiryStatus(v.licence_expire_date, v.licence_issued_date, v.metadata);
                    const isExpired = status.isExpired;
                    return (
                      <tr key={v.id} style={{ borderBottom: '1px solid #F1F5F9' }}>
                        <td style={{ padding: '16px 20px', fontSize: '14px', color: '#111827', fontWeight: 500 }}>{v.name}</td>
                        <td style={{ padding: '16px 20px', fontSize: '14px', color: '#475569' }}>{v.plate || '-'}</td>
                        <td style={{ padding: '16px 20px', fontSize: '14px', color: '#475569' }}>{formatLocalDate(v.licence_expire_date)}</td>
                        <td style={{ padding: '16px 20px' }}>
                          <span style={{
                            padding: '6px 12px', borderRadius: '12px', fontSize: '12px', fontWeight: 700,
                            background: isExpired ? '#FEE2E2' : '#FEF3C7',
                            color: isExpired ? '#DC2626' : '#D97706'
                          }}>
                            {status.text}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', minHeight: '200px', gap: '12px', opacity: 0.6 }}>
                <AlertTriangle size={32} color="#94A3B8" />
                <p style={{ fontSize: '15px', color: '#64748B', fontWeight: 500, margin: 0 }}>All vehicle licenses are active and up to date!</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
