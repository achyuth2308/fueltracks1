// ============================================================
// REDIS PUBLISHER
// Publishes parsed packets to Redis channels
// Updates live vehicle state cache
// ============================================================

const Redis = require('ioredis');

const REDIS_HOST = process.env.REDIS_HOST || 'localhost';
const REDIS_PORT = process.env.REDIS_PORT || 6379;

let publisher = null;

/**
 * Initialize Redis publisher connection
 */
function init() {
  publisher = new Redis({
    host: REDIS_HOST,
    port: REDIS_PORT,
    retryStrategy: (times) => {
      const delay = Math.min(times * 100, 3000);
      console.log(`[REDIS] Reconnecting in ${delay}ms... (attempt ${times})`);
      return delay;
    },
    maxRetriesPerRequest: null,
  });

  publisher.on('connect', () => {
    console.log(`[REDIS] Publisher connected to ${REDIS_HOST}:${REDIS_PORT}`);
  });

  publisher.on('error', (err) => {
    console.error('[REDIS] Publisher error:', err.message);
  });

  return publisher;
}

/**
 * Publish a parsed normal packet ($10) to Redis
 * 1. Publish to 'tracking' channel (for DB writer + Socket.io)
 * 2. Cache latest state in vehicle:state:{imei}
 * 3. Set online indicator with 90s TTL
 */
async function publishLocation(parsed) {
  if (!publisher) throw new Error('Redis publisher not initialized');

  let { imei, lat, lng, speed, fuel, ignition, voltage, direction,
          odometer, satellites, gsmSignal, battery, deviceTime, isLive,
          rawPacket, packetType } = parsed;

  // Validate coordinates — reject 0,0 or out-of-range values
  const isInvalidCoords = !lat || !lng
    || parseFloat(lat) === 0 && parseFloat(lng) === 0
    || Math.abs(parseFloat(lat)) > 90
    || Math.abs(parseFloat(lng)) > 180;

  if (isInvalidCoords) {
    // Try to restore last known valid location from Redis cache
    let restored = false;
    try {
      const prevStateRaw = await publisher.get(`vehicle:state:${imei}`);
      if (prevStateRaw) {
        const prevState = JSON.parse(prevStateRaw);
        if (prevState && prevState.lat && prevState.lng
            && Math.abs(parseFloat(prevState.lat)) > 0.001
            && Math.abs(parseFloat(prevState.lng)) > 0.001) {
          lat = prevState.lat;
          lng = prevState.lng;
          restored = true;
        }
        // Always restore voltage from cache if missing in current packet
        if (!voltage && prevState && prevState.voltage) {
          voltage = prevState.voltage;
        }
      }
    } catch (e) {
      // Ignore JSON parse error on stale cache
    }

    // No valid cached coords either — drop the packet entirely.
    // NEVER fabricate or guess coordinates; that corrupts production data.
    if (!restored) {
      console.warn(`[REDIS] Dropping packet for ${imei}: invalid GPS fix (${lat},${lng}) and no valid cached location`);
      return;
    }
  }

  const payload = JSON.stringify({
    imei,
    lat,
    lng,
    speed,
    fuel,
    ignition,
    voltage,
    direction,
    odometer,
    satellites,
    gsmSignal,
    battery,
    deviceTime,
    isLive,
    rawHex: rawPacket,
    packetType,
    serverTime: new Date().toISOString(),
  });

  try {
    // 1. Publish to tracking channel
    await publisher.publish('tracking', payload);

    // 3. Set online indicator with 90-second TTL
    await publisher.set(
      `vehicle:online:${imei}`,
      '1',
      'EX', 90
    );

  } catch (err) {
    console.error(`[REDIS] Publish error for ${imei}:`, err.message);
  }
}

/**
 * Publish a heartbeat or health packet to Redis
 * Updates last_seen without creating a new GPS history point
 */
async function publishHeartbeat(imei, battery, gsmSignal, ignition, deviceTime, rawPacket, packetType) {
  if (!publisher) throw new Error('Redis publisher not initialized');

  try {
    const prevStateRaw = await publisher.get(`vehicle:state:${imei}`);
    const prevState = prevStateRaw ? JSON.parse(prevStateRaw) : {};
    
    const payload = JSON.stringify({
      ...prevState,
      imei: imei,
      battery: battery !== undefined ? battery : prevState.battery,
      gsmSignal: gsmSignal !== undefined ? gsmSignal : prevState.gsmSignal,
      ignition: ignition !== undefined ? ignition : prevState.ignition,
      deviceTime: deviceTime || prevState.deviceTime,
      rawHex: rawPacket || prevState.rawHex,
      packetType: packetType || prevState.packetType,
      serverTime: new Date().toISOString(),
      isHeartbeat: true, // Special flag for subscriber
      isLive: true
    });

    // 1. Publish to tracking channel (Subscriber will handle isHeartbeat logic)
    await publisher.publish('tracking', payload);

    // 3. Set online indicator with 90-second TTL
    await publisher.set(
      `vehicle:online:${imei}`,
      '1',
      'EX', 90
    );
  } catch (err) {
    console.error(`[REDIS] Heartbeat publish error for ${imei}:`, err.message);
  }
}

/**
 * Publish a parsed alert packet ($11) to Redis
 */
async function publishAlert(parsed) {
  if (!publisher) throw new Error('Redis publisher not initialized');

  const payload = JSON.stringify({
    imei: parsed.imei,
    alertType: parsed.alertType,
    alertText: parsed.alertText,
    lat: parsed.lat,
    lng: parsed.lng,
    deviceTime: parsed.deviceTime,
    rawHex: parsed.rawPacket,
    packetType: parsed.packetType,
    serverTime: new Date().toISOString(),
  });

  try {
    await publisher.publish('alerts', payload);
  } catch (err) {
    console.error(`[REDIS] Alert publish error for ${parsed.imei}:`, err.message);
  }
}

/**
 * Publish raw message to a dedicated raw_logs channel.
 * Strips null bytes (\u0000) from the serialized payload before publishing —
 * PostgreSQL TEXT columns (and the Redis string round-trip) reject 0x00 bytes.
 */
async function publishRawMessage(parsed) {
  if (!publisher) return;
  // Build a safe, lean metadata object — exclude raw binary blobs to prevent
  // oversized or circular-reference JSON that would cause JSON.stringify to throw.
  const safeParsedJson = {
    packetType: parsed.packetType,
    imei: parsed.imei,
    lat: parsed.lat,
    lng: parsed.lng,
    speed: parsed.speed,
    direction: parsed.direction,
    ignition: parsed.ignition,
    voltage: parsed.voltage,
    battery: parsed.battery,
    gpsValid: parsed.gpsValid,
    satellites: parsed.satellites,
    deviceTime: parsed.deviceTime,
    alertType: parsed.alertType || null,
    alertText: parsed.alertText || null,
    isLive: parsed.isLive,
    odometer: parsed.odometer,
    error: parsed.error || null,
  };

  let rawPayload;
  try {
    rawPayload = JSON.stringify({
      imei: parsed.imei,
      packetType: parsed.packetType,
      rawHex: parsed.rawPacket || parsed.rawString || null,
      rawString: parsed.rawString || parsed.rawPacket || null,
      deviceTime: parsed.deviceTime || new Date().toISOString(),
      odometer: parsed.odometer !== undefined && parsed.odometer !== null ? parsed.odometer : null,
      parsedJson: safeParsedJson,
      parsed: parsed.parsed !== false,
      error: parsed.error || null,
    });
  } catch (serErr) {
    console.error('[REDIS] Raw log serialization error:', serErr.message);
    return;
  }
  // Remove all null byte characters (0x00) which PostgreSQL UTF-8 rejects
  const payload = rawPayload.replace(/\0/g, '');
  try {
    await publisher.publish('raw_logs', payload);
  } catch (err) {
    console.error('[REDIS] Raw log publish error:', err.message);
  }
}

/**
 * Close Redis connection
 */
async function close() {
  if (publisher) {
    await publisher.quit();
    publisher = null;
  }
}

module.exports = { init, publishLocation, publishHeartbeat, publishAlert, publishRawMessage, close };
