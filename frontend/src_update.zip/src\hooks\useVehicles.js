import { useState, useEffect, useCallback } from 'react';
import * as vehicleApi from '../api/vehicleApi';
import * as adminApi from '../api/adminApi';
import { useSocket } from './useSocket';

export const useVehicles = (initialParams = {}) => {
  const [vehicles, setVehicles] = useState([]);
  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [params, setParams] = useState(initialParams);
  const [pagination, setPagination] = useState({ page: 1, limit: 100, total: 0, totalPages: 1 });

  const { socket, connected, joinVehicleRoom, leaveVehicleRoom } = useSocket();

  const fetchVehicles = useCallback(async (currentParams = params) => {
    setLoading(true);
    try {
      const response = await vehicleApi.getVehicles({ ...currentParams, t: Date.now() });
      if (response.success) {
        const sanitizedData = (response.data || []).map(v => {
          if (!v.is_online) {
            return { ...v, current_ignition: false, current_speed: 0 };
          }
          return v;
        });
        setVehicles(sanitizedData);
        if (response.pagination) {
          setPagination(response.pagination);
        }
        setError(null);
      }
    } catch (err) {
      console.error('Failed to load vehicles:', err);
      setError(err.response?.data?.error || 'Failed to fetch vehicles');
    } finally {
      setLoading(false);
    }
  }, [params]);

  const fetchGroups = useCallback(async () => {
    try {
      const response = await adminApi.getGroups();
      if (response.success) {
        setGroups(response.data);
      }
    } catch (err) {
      console.error('Failed to load groups:', err);
    }
  }, []);

  // Fetch initial data
  useEffect(() => {
    fetchVehicles();
    fetchGroups();
  }, [fetchVehicles, fetchGroups]);

  // Polling fallback when WebSocket is disconnected (prevents tab suspension freezes)
  useEffect(() => {
    let pollInterval = null;
    if (!connected) {
      console.log('[useVehicles] Socket disconnected. Starting 30s API polling fallback...');
      pollInterval = setInterval(() => {
        fetchVehicles();
      }, 30000);
    }
    return () => {
      if (pollInterval) {
        clearInterval(pollInterval);
      }
    };
  }, [connected, fetchVehicles]);

  const vehicleIdsStr = vehicles.map(v => v.id).sort().join(',');

  // Subscribe to individual vehicle rooms to receive live location updates
  useEffect(() => {
    if (!socket || !connected || vehicles.length === 0) return;

    vehicles.forEach(vehicle => {
      joinVehicleRoom(vehicle.id);
    });

    return () => {
      vehicles.forEach(vehicle => {
        leaveVehicleRoom(vehicle.id);
      });
    };
  }, [socket, connected, vehicleIdsStr, joinVehicleRoom, leaveVehicleRoom]);

  // Handle Socket.io real-time updates for matching vehicles in the list
  useEffect(() => {
    if (!socket) return;

    const handleFleetUpdate = (data) => {
      // data: { vehicleId, lat, lng, speed, ignition, ... }
      setVehicles((prevVehicles) =>
        prevVehicles.map((vehicle) => {
          if (vehicle.id === data.vehicleId) {
              const isOnlineStatus = data.is_online !== undefined ? data.is_online : (data.isOnline !== undefined ? data.isOnline : true);
              return {
                ...vehicle,
                lat: data.lat,
                lng: data.lng,
                current_speed: isOnlineStatus ? (data.speed || 0) : 0,
                current_ignition: isOnlineStatus ? !!data.ignition : false,
                current_fuel: data.fuel !== undefined && data.fuel !== null ? data.fuel : vehicle.current_fuel,
                current_voltage: data.voltage !== undefined && data.voltage !== null ? data.voltage : vehicle.current_voltage,
                current_odometer: data.odometer !== undefined && data.odometer !== null ? data.odometer : vehicle.current_odometer,
                current_direction: data.direction !== undefined && data.direction !== null ? data.direction : vehicle.current_direction,
                current_satellites: data.satellites !== undefined && data.satellites !== null ? data.satellites : vehicle.current_satellites,
                current_gsm_signal: data.gsmSignal !== undefined && data.gsmSignal !== null ? data.gsmSignal : vehicle.current_gsm_signal,
                is_online: isOnlineStatus,
                today_distance: data.today_distance !== undefined ? data.today_distance : vehicle.today_distance,
                last_seen: data.deviceTime || new Date().toISOString(),
              };
          }
          return vehicle;
        })
      );
    };

    socket.on('fleet:update', handleFleetUpdate);
    socket.on('location:update', handleFleetUpdate);

    return () => {
      socket.off('fleet:update', handleFleetUpdate);
      socket.off('location:update', handleFleetUpdate);
    };
  }, [socket]);

  const updateParams = useCallback((newParams) => {
    setParams((prev) => {
      const updated = { ...prev, ...newParams };
      fetchVehicles(updated);
      return updated;
    });
  }, [fetchVehicles]);

  return {
    vehicles,
    groups,
    loading,
    error,
    params,
    pagination,
    updateParams,
    refetch: fetchVehicles,
  };
};
