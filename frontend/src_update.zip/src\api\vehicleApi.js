import axiosInstance from './axios';

export const getVehicles = async (params = {}) => {
  const response = await axiosInstance.get('/api/vehicles', { params });
  return response.data;
};

export const getTodayMetrics = async () => {
  const response = await axiosInstance.get('/api/vehicles/today-metrics');
  return response.data;
};

export const getVehicleById = async (id) => {
  const response = await axiosInstance.get(`/api/vehicles/${id}`);
  return response.data;
};

export const createVehicle = async (data) => {
  const response = await axiosInstance.post('/api/vehicles', data);
  return response.data;
};

export const updateVehicle = async (id, data) => {
  const response = await axiosInstance.put(`/api/vehicles/${id}`, data);
  return response.data;
};

export const deleteVehicle = async (id) => {
  const response = await axiosInstance.delete(`/api/vehicles/${id}`);
  return response.data;
};

export const migrateVehicle = async (id, newImei) => {
  const response = await axiosInstance.post(`/api/vehicles/${id}/migrate`, { newImei });
  return response.data;
};

export const bulkAssignGroups = async (vehicleIds, groupIds, mode = 'replace') => {
  const response = await axiosInstance.post('/api/vehicles/bulk-assign-groups', { vehicleIds, groupIds, mode });
  return response.data;
};

export const getVehicleHistory = async (id, params = {}) => {
  // History can return large payloads — use 60s timeout to prevent false logouts
  const response = await axiosInstance.get(`/api/vehicles/${id}/history`, { params, timeout: 60000 });
  return response.data;
};

export const getVehicleRoute = async (id, params = {}) => {
  // Route data can be 300KB+ — use 60s timeout to prevent false logouts
  const response = await axiosInstance.get(`/api/vehicles/${id}/route`, { params, timeout: 60000 });
  return response.data;
};

export const getVehicleReport = async (id, params = {}) => {
  const response = await axiosInstance.get(`/api/vehicles/${id}/report`, { params });
  return response.data;
};

export const getVehicleAlerts = async (id, params = {}) => {
  const response = await axiosInstance.get(`/api/vehicles/${id}/alerts`, { params });
  return response.data;
};

export const setVehicleImmobilizer = async (id, action) => {
  const response = await axiosInstance.post(`/api/vehicles/${id}/immobilizer`, { action });
  return response.data;
};
